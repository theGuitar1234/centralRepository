package com.example;

import org.springframework.beans.BeansException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.entities.Animals.Cats.Cat;
import com.entities.Cars.Car;
import com.entities.Cars.Conditioners.Conditioner;
import com.entities.Cars.Engines.Abach;
//import com.entities.Cars.Engines.Engine;
import com.entities.Cars.Engines.PetrolEngine;
import com.entities.Plants.Plant;

public class App {
    public static void main(String[] args) {
        
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class)) {

            //Engine engine = context.getBean(Engine.class);
            //engine.start();
            //engine.setType();
            //System.out.println(engine.getType());

            PetrolEngine abach = new Abach();
            abach.setType();
            System.out.println(abach.getType());

            Conditioner conditioner = context.getBean("Toyota", Conditioner.class);
            conditioner.ventilate();

            Car car = context.getBean(Car.class);
            //car.setEngine(engine);
            car.setConditioner(conditioner);

            car.drive();
            car.turnOnTheAirSystem();

            Plant plant = context.getBean(Plant.class);
            plant.place();

            Cat cat = context.getBean("Chot", Cat.class);
            cat.meow();

        } catch(BeansException e) {
            e.printStackTrace();
        }
        
    }
}
