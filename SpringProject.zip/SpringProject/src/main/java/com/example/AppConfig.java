package com.example;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.entities.Animals.Cats.Chili;
import com.entities.Animals.Cats.Chot;

@Configuration
@ComponentScan("com.entities")
public class AppConfig {
    @Bean("Chili")
    public Chili chili() {
        return new Chili();
    }

    @Bean("Chot")
    public Chot chot() {
        return new Chot();
    }
}
