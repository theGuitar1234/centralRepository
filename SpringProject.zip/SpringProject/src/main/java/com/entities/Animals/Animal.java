package com.entities.Animals;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

interface Engine {
    public void start();
}

@Component("PetrolEngine")
class PetrolEngine implements Engine {
    @Override
    public void start() {
        System.out.println("The Petrol Engine is started");
    }
}

@Component("DieselEngine")
class DieselEngine implements Engine {
    @Override
    public void start() {
        System.out.println("The Diesel Engine is started");
    }
}

@Component("Car")
class Car {
    private Engine engine;

    public Engine getEngine() {
        return engine;
    }

    @Autowired
    public Car(Engine engine) {
        this.engine = engine;
    }

    public void drive() {
        engine.start();
        System.out.println("The Car is driving");
    }

}

@Configuration
@ComponentScan("entities")
class MainConfig {

}

public class Animal {
    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MainConfig.class)) {
            Car car = context.getBean("PetrolEngine", Car.class);
            car.drive();
        } catch(BeansException e) {
            e.printStackTrace();
        }
    }
}
