package com.entities.Animals.Cats;

public class Chili implements Cat {
    @Override
    public void meow() {
        System.out.println("Meow meow meow... Chili");
    }
}
