package com.entities.Animals.Cats;

public interface Cat {
    public void meow();
}
