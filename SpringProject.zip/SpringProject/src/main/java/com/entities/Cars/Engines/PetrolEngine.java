package com.entities.Cars.Engines;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("PetrolEngine")
public class PetrolEngine implements Engine {

    @Autowired
    private Engine engine;

    public Engine getEngine() {
        return engine;
    }

    private String type = Engine.type;

    @Override
    public String getType() {
        return this.type;
    }

    @Override 
    public void setType() {
        this.type = "V8";
    }

    @Override
    public void start() {
        System.out.println("The Petrol Engine is started");
    }

}
