package com.entities.Cars.Conditioners;

import org.springframework.stereotype.Component;

@Component("Corola")
public class Corola implements Conditioner {

    @Override
    public void ventilate() {
        System.out.println("The Corola Conditioner is started");
    }
    
}
