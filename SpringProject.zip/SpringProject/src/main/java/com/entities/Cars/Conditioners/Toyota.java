package com.entities.Cars.Conditioners;

import org.springframework.stereotype.Component;

@Component("Toyota")
public class Toyota implements Conditioner {

    @Override
    public void ventilate() {
        System.out.println("The Toyota Conditioner is started");
    }
    
}
