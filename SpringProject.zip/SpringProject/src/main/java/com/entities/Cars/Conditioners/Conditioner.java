package com.entities.Cars.Conditioners;

public interface Conditioner {
    void ventilate();
}
