package com.entities.Cars.Engines;

public class Abach extends PetrolEngine {

    private PetrolEngine petrolEngine = new PetrolEngine();

    public PetrolEngine getPetrolEngine() {
        return petrolEngine;
    }

    private String type = getPetrolEngine().getType();

    @Override
    public String getType() {
        return this.type;
    }
 
    @Override
    public void setType() {
        this.type = "V6";
    }

    @Override
    public void start() {
        System.out.println("The Abach is started");
    }

}
