package com.entities.Cars.Engines;

public interface Engine {
    public String type = "V12";
    public String getType();
    public void setType();
    void start();
}


