package com.entities.Cars;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.core.annotation.AliasFor;
import org.springframework.stereotype.Component;

import com.entities.Cars.Conditioners.Conditioner;
import com.entities.Cars.Engines.Engine;

@Component("Car")
public class Car {
    @Autowired
    //@Qualifier("PetrolEngine")
    private Engine engine;

    //public Engine getEngine() {
    //     return engine;
    //}

    @Autowired
    @Qualifier("DieselEngine")
    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    private Conditioner conditioner;

    public Conditioner getConditioner() {
        return conditioner;
    }

    public void setConditioner(Conditioner conditioner) {
        this.conditioner = conditioner;
    }

    public void turnOnTheAirSystem() {
        System.out.println("The Air System is turned on");
        getConditioner().ventilate();
    }

    public void drive() {
        engine.start();
        System.out.println("The Car is driving");
    }
}
