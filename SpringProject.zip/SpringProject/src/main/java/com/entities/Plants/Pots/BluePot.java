package com.entities.Plants.Pots;

import org.springframework.stereotype.Component;

@Component("BluePot")
public class BluePot implements Pot{

    @Override
    public void contain() {
        System.out.println("The BluePot contains a plant");
    }
    
}
