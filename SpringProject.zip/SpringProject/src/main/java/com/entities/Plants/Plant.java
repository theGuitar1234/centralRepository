package com.entities.Plants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.entities.Plants.Pots.Pot;

@Component("Plant")
public class Plant {
    //@Autowired
    private Pot pot; //Field Injection

    public Pot getPot() {
        return pot;
    }

    public void setPot(Pot pot) {
        this.pot = pot;
    }

    @Autowired
    public Plant(Pot pot) {
        this.pot = pot;
    }

    public void place() {
        getPot().contain();
        System.out.println("The Plant is contained");
    }

}