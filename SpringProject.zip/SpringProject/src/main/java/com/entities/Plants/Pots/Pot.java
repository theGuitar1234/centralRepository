package com.entities.Plants.Pots;

public interface Pot {
    void contain();
}
