package org.application.spring_boot_application.Admin.Services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.application.spring_boot_application.Admin.Entities.User;
import org.application.spring_boot_application.Admin.Repositories.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
    
    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User save(User user) {
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(LocalDateTime.now());
        }
        User savedUser = userRepository.save(user);
      
        return savedUser;
    }

    public User getUserById(Long id) {
        Optional<User> userOptional = userRepository.findByUserId(id);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public User getUserByUsernameString(String username) {
        Optional<User> userOptional = userRepository.findByUsernameString(username);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public User getUserByEmailString(String emailString) {
        Optional<User> userOptional = userRepository.findByEmailString(emailString);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional
    public void deleteUserById(Long userId) {
        userRepository.deleteUserById(userId);
    }
  
    @Transactional
    public void updateUserPassword(Long id, String passwordString) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not Found"));
        
        user.setPasswordString(passwordEncoder.encode(passwordString));
    }

}
