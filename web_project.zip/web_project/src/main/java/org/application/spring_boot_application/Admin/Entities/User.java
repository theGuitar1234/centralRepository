package org.application.spring_boot_application.Admin.Entities;

import java.time.LocalDateTime;

import org.application.spring_boot_application.Web.Validations.EmailValidation;
import org.application.spring_boot_application.Web.Validations.PasswordValidation;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Component
@NoArgsConstructor
@ToString
@Table(name = "Users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(name = "username", nullable = false, unique = true)
    private String usernameString;
    
    @EmailValidation
    @Column(name = "email", unique = true)
    private String emailString;

    @PasswordValidation
    @Column(name = "password")
    private String passwordString;

    @Column(name = "creation_date", nullable = false)
    private LocalDateTime createdAt;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "roleId")
    private Role role;

    public void addRole(Role role) {
        this.setRole(role);
        role.addUser(this);
    }

}

