package org.application.spring_boot_application.Admin.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import org.springframework.stereotype.Service;
import org.application.spring_boot_application.Admin.Entities.Authority;
import org.application.spring_boot_application.Admin.Entities.Role;
import org.application.spring_boot_application.Admin.Entities.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserService userService;

    public CustomUserDetailsService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userService.getUserByUsernameString(username);

        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();

        Role role = user.getRole();

        grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleNameString()));

        for (Authority i : role.getAuthorities()) {
            grantedAuthorities.add(new SimpleGrantedAuthority(i.getAuthorityNameString()));
        }

        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername(user.getUsernameString())
                                                                                        .password(user.getPasswordString())
                                                                                        .authorities(grantedAuthorities)
                                                                                        .build();
        return userDetails;
    }
    
}
