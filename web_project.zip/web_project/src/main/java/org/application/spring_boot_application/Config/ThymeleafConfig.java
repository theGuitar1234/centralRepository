package org.application.spring_boot_application.Config;

import org.thymeleaf.extras.springsecurity6.dialect.SpringSecurityDialect;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ThymeleafConfig {
    @Bean
    SpringSecurityDialect springSecurityDialect() {
        return new SpringSecurityDialect();
    }
}
