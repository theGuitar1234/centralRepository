package org.application.spring_boot_application.SeedData;

import java.util.Set;

import org.application.spring_boot_application.Admin.Entities.Authority;
import org.application.spring_boot_application.Admin.Entities.Role;
import org.application.spring_boot_application.Admin.Entities.User;
import org.application.spring_boot_application.Admin.Services.AuthorityService;
import org.application.spring_boot_application.Admin.Services.CustomUserDetailsService;
import org.application.spring_boot_application.Admin.Services.RoleService;
import org.application.spring_boot_application.Admin.Services.UserService;
import org.application.spring_boot_application.util.constants.authorities;
import org.application.spring_boot_application.util.constants.roles;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class SeedData implements CommandLineRunner {

    private final UserService userService;

    private final AuthorityService authorityService;

    private final CustomUserDetailsService userDetailsService;

    private final PasswordEncoder passwordEncoder;

    private final RoleService roleService;

    public SeedData(UserService userService, AuthorityService authorityService, CustomUserDetailsService userDetailsService, PasswordEncoder passwordEncoder, RoleService roleService) {
        this.userService = userService;
        this.authorityService = authorityService;
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
        this.roleService = roleService;
    }

    @Override
    public void run(String... args) throws Exception {

        for (authorities auth : authorities.values()) {
            Authority authority = new Authority();

            authority.setAuthorityId(auth.getAuthorityId());
            authority.setAuthorityNameString(auth.getAuthorityString());

            authorityService.save(authority);
        }

        for (roles role : roles.values()) {
            Role roleTemp = new Role();

            roleTemp.setRoleId(role.getRoleId());
            roleTemp.setRoleNameString(role.getRoleString());

            Set<Long> authorityIds;

            switch (roleTemp.getRoleNameString()) {
                case "ADMIN":
                    authorityIds = Set.of(authorities.ACCESS_ADMIN_PANEL.getAuthorityId(),  
                                                    authorities.DELETE_ANY_USER.getAuthorityId(),
                                                    authorities.SET_ANY_ROLE.getAuthorityId(),
                                                    authorities.RESET_ANY_USER_PASSWORD.getAuthorityId(),
                                                    authorities.READ_ANY_CONTENT.getAuthorityId());
                    break;
                case "USER":
                    authorityIds = Set.of(authorities.READ_ANY_CONTENT.getAuthorityId());
                    break;
                default:
                    throw new RuntimeException("Invalid roleString");
            }

            for (Long authorityId : authorityIds) {
                Authority authority = authorityService.getByAuthorityId(authorityId);

                roleTemp.addAuthority(authority);
                authority.addRole(roleTemp);
            }

            roleService.save(roleTemp);
        }

        User user1 = new User();
        User user2 = new User();

        user1.setUsernameString("Guitar11");
        user1.setEmailString("tantenontam@gmail.com");
        user1.setPasswordString(passwordEncoder.encode("TURANTURANTURANturan2006@"));
        user1.addRole(roleService.getByRoleId(roles.ADMIN.getRoleId()));
        
        user2.setUsernameString("Guitar12");
        user2.setEmailString("tantenontam1@gmail.com");
        user2.setPasswordString(passwordEncoder.encode("TURANTURANTURANturan2006@"));
        user2.addRole(roleService.getByRoleId(roles.USER.getRoleId()));

        userService.save(user1);
        userService.save(user2);

        userDetailsService.loadUserByUsername(user1.getUsernameString());
        userDetailsService.loadUserByUsername(user2.getUsernameString());
        
    }
}

