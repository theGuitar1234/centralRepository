package org.application.spring_boot_application.Admin.Services;

import java.util.Optional;

import org.application.spring_boot_application.Admin.Entities.Role;
import org.application.spring_boot_application.Admin.Repositories.RoleRepository;
import org.springframework.stereotype.Service;

@Service
public class RoleService {

    private final RoleRepository roleRepository;

    public RoleService(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    public Role save(Role role) {
        Role savedRole = roleRepository.save(role);
        return savedRole;
    }

    public Role getByRoleId(Long id) {
        Optional<Role> roleOptional = roleRepository.findByRoleId(id);
        Role role = roleOptional.orElseThrow(() -> new RuntimeException("Role not Found"));
        return role;
    }

    public Role getByRoleNameString(String roleNameString) {
        Optional<Role> roleOptional = roleRepository.findByRoleNameString(roleNameString);
        Role role = roleOptional.orElseThrow(() -> new RuntimeException("Role Not Found"));
        return role;
    }

}
