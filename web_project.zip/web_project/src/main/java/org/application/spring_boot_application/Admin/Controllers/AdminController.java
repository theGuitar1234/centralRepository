package org.application.spring_boot_application.Admin.Controllers;

import org.application.spring_boot_application.Admin.Entities.Role;
import org.application.spring_boot_application.Admin.Entities.User;
import org.application.spring_boot_application.Admin.Services.RoleService;
import org.application.spring_boot_application.Admin.Services.UserService;
import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.transaction.Transactional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    private final UserService userService;

    private final RoleService roleService;

    public AdminController(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    @GetMapping("/")
    @PreAuthorize("hasAuthority('ACCESS_ADMIN_PANEL')")
    public String admin(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "admin";
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('DELETE_ANY_USER')")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUserById(id);
        return "redirect:/admin/";
    }

    @Transactional
    @PostMapping("/add_role")
    public String addRole(@RequestParam Long userId, @RequestParam String role) {

        User user = userService.getUserById(userId);
        Role roleTemp = roleService.getByRoleNameString(role);

        user.addRole(roleTemp);

        return "redirect:/admin/";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/resetPassword")
    public String resetPassword(@RequestParam Long userId, @RequestParam String password) {
        userService.updateUserPassword(userId, password);
        return "redirect:/admin/";
    }
    
}
