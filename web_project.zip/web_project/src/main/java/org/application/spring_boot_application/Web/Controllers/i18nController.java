package org.application.spring_boot_application.Web.Controllers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

import org.application.spring_boot_application.Web.Services.i18nService;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/i18n")
public class i18nController {

    private final i18nService i18nService;

    public i18nController(i18nService i18nService) {
        this.i18nService = i18nService;
    }

    @GetMapping("/change_language")
    public String changeLanguage(@RequestParam("redirectUrl") String redirectUrl) {
        return "redirect:" + redirectUrl;
    }

    @PostMapping("/update_messages")
    public String updateMessage(@RequestParam Map<String, String> params, HttpServletRequest request) throws FileNotFoundException, IOException {
        i18nService.updateMessages(params, request);
        return "redirect:/login/" ;
    }
    
}
