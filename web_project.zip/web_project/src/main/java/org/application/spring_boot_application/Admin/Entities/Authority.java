package org.application.spring_boot_application.Admin.Entities;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="Authorities")
@Getter
@Setter
@NoArgsConstructor
public class Authority {
    @Id
    private Long authorityId;

    @Column(name="authority_name")
    private String authorityNameString;

    @JsonIgnore
    @ManyToMany(mappedBy = "authorities")
    private Set<Role> roles = new HashSet<>();

    public void addRole(Role role) {
        roles.add(role);
    }
    
    @Override
    public String toString() {
        return "Authority [authorityId=" + authorityId + ", authorityNameString=" + authorityNameString + "]";
    }
}
