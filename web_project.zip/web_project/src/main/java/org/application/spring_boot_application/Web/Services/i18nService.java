package org.application.spring_boot_application.Web.Services;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Service
public class i18nService {

    private static String localeString;

    private static String FILE_PATH;

    public void updateMessages(Map<String, String> params, HttpServletRequest request) throws FileNotFoundException, IOException {

        System.out.println(params);

        HttpSession session = request.getSession();
        localeString = session.getAttribute("lang").toString();

        FILE_PATH = "i18n/messages_" + localeString + ".properties";

        try (FileInputStream input = new FileInputStream(FILE_PATH)) {
            Properties properties = new Properties();
            properties.load(input);
            input.close();

            for (String i : params.keySet()) {
                properties.setProperty(i, params.get(i));
            }

            try (FileOutputStream output = new FileOutputStream(FILE_PATH)) {
                properties.store(output, "Messages got Updated");
            }
        }
    }
}
