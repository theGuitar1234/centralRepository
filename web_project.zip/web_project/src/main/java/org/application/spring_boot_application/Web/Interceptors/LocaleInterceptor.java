package org.application.spring_boot_application.Web.Interceptors;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Component
public class LocaleInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String lang = request.getParameter("lang");
        HttpSession session = request.getSession();
        if (lang != null) {
            session.setAttribute("lang", lang);
        } else {
            session.setAttribute("lang", "en");
        }
        return true;
    }
}
